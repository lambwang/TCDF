rm(list=ls())
cat('\14')
# read USD Index
USD_index = data.frame(read.csv(file = '~/Desktop/TCDF/data/USIndex/DTWEXB.csv',sep=','))
colnames(USD_index) = c('Date','Value')


head(USD_index,50)
normalize <- function(x) {
  return(ifelse(is.na(x), NA, (x - min(x)) / (max(x) - min(x))))
}
lapply(USD_index$Value,normalize)

#USD_index$Value[USD_index$Value == '.'] <- NA
#USD_index_mean = mean(USD_index$Value,na.rm=TRUE)
#USD_index_sd = sd(USD_index$Value,na.rm=TRUE)
#write.csv(file = '~/Desktop/TCDF/data/USIndex/USDIndex.csv')